javadoc Main.java # use javadoc to make it
npx static-here # this is just for viewing it in the web