public class Person {

    private String name;
    private int age;

    // Constructor to initialize a Person object with a name and age
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Method to set the name of the person
    public void setName(String name) {
        this.name = name;
    }

    // Method to set the age of the person
    public void setAge(int age) {
        this.age = age;
    }

    // Method to display information about the person
    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age + " years");
    }
}
