public class Main {
    public static void main(String[] args) {
        // Your main method logic here
        Person person = new Person("John Doe", 25);
        person.displayInfo();
    }
}
